import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-evident',
  templateUrl: './evident.component.html',
  styleUrls: ['./evident.component.scss']
})
export class EvidentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

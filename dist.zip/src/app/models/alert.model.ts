export interface IAlert {
    open: boolean;
    type: string;
    title: string;
    subTitle: string;
}
export interface iAddressForm {
    visible: boolean;
    departamento: String;
    ciudad: String;
    tipo_via: String;
    via_principal: String;
    via_secundaria: String;
    numero: String;
    complemento?: String;
    fieldDestinity: String

}
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-not-approved',
  templateUrl: './not-approved.component.html',
  styleUrls: ['./not-approved.component.scss']
})
export class NotApprovedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

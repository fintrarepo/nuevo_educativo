export const environment = {
  production: true,
  apiPath: "https://prometheus.fintra.co:8443/fintracredit",
  fintra: "https://prometheus.fintra.co:8444/fintra",
  reconocer:"https://recidaw.olimpiait.com"
};
 